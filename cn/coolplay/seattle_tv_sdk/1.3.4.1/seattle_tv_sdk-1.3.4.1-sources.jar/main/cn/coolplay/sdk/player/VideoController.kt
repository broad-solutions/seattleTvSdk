package cn.coolplay.sdk.player

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.AttributeSet
import android.view.ViewGroup
import androidx.annotation.Keep
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.size
import androidx.media3.common.Player
import androidx.media3.ui.PlayerControlView
import cn.coolplay.sdk.player.component.ControlComponent
import cn.coolplay.sdk.utils.print

@Keep
open class VideoController
@JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : ConstraintLayout(context, attrs, defStyleAttr), Player.Listener {


    /**
     * 当前控制器中保存的所有控制组件
     */
    @JvmField
    protected val controlComponents = LinkedHashMap<ControlComponent, Boolean>()

    fun setPlayerController(
        @SuppressLint("UnsafeOptInUsageError") controlView: PlayerControlView?,
        videoController: VideoController,
        player: Player?
    ) {
        for ((item, isDissociate) in controlComponents) {
            item.attachController(
                controlView, videoController, player
            )
            if (isDissociate) {
                if (item.view.parent != null)
                    (item.view.parent as ViewGroup).removeView(item.view)
                addView(
                    item.view,
                    0,
                    ViewGroup.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
                )
            }
            "rootView:$size}".print("VideoController")
        }
    }

    /**
     * 通知所有控制组件
     */
    open fun postEvent(bundle: Bundle) {
        for ((component) in controlComponents) {
            component.postEvent(bundle)
        }
    }

    /**
     * 通知指定控制组件
     */
    open fun postEvent(tag: String, bundle: Bundle) {
        controlComponents.keys.firstOrNull { it.tag == tag }?.postEvent(bundle)
    }

    /**
     * 添加控制组件，最后面添加的在最下面，合理组织添加顺序，可让ControlComponent位于不同的层级
     */
    fun addControlComponent(vararg component: ControlComponent) {
        for (item in component) {
            addControlComponent(item, true)
        }
    }

    fun addControlComponent(component: ControlComponent, isDissociate: Boolean) {
        controlComponents[component] = isDissociate
    }

    /**
     * 移除所有控制组件
     */
    fun removeAllControlComponent() {
        for ((component) in controlComponents) {
            removeControlComponentView(component)
        }
        controlComponents.clear()
    }

    /**
     * 从当前控制器中移除添加的控制器view
     *
     * @param component
     */
    private fun removeControlComponentView(component: ControlComponent) {
        removeView(component.view)
    }
}