package cn.coolplay.sdk.loader.coolplay

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.Util
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.ima.ImaAdsLoader
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.loader.AdRequestBuilder
import cn.coolplay.sdk.loader.CoolBaseControl
import cn.coolplay.sdk.loader.CoolPlayAdControl
import cn.coolplay.sdk.loader.CoolPlayAdListener
import cn.coolplay.sdk.player.ClPlayerView
import cn.coolplay.sdk.utils.print
import cn.coolplay.seattle_tv_sdk.databinding.ClLayoutPlayerBinding
import com.google.ads.interactivemedia.v3.api.AdEvent.AdEventType
import com.google.ads.interactivemedia.v3.api.ImaSdkFactory
import com.google.ads.interactivemedia.v3.api.ImaSdkSettings
import com.google.ads.interactivemedia.v3.api.player.AdMediaInfo
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer.VideoAdPlayerCallback
import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate
import com.google.gson.Gson
import java.io.File


/**
 * 处理 IMA SDK 集成代码和事件的广告逻辑。
 */
@SuppressLint("UnsafeOptInUsageError")
class VideoPlayerController(
    adLoadController: CoolPlayAdControl,
    override var channel: String // 确保 channel 是通过构造函数初始化的
) : CoolBaseControl {
    private val imaRequestBuilder: AdRequestBuilder = adLoadController.adRequestBuilder
    private var imaAdsLoader: ImaAdsLoader? = null
    private val context get() = imaRequestBuilder.context
    private var exoPlayer: ExoPlayer? = null
    private var playerView: ClPlayerView? = null

    // 用于请求广告的 VAST 广告标签 URL。
    private var currentAdTagUrl: String? = null
    private var isReleased = false
    private var isInitializer = false
    private val mUserAgent: String by lazy {
        Util.getUserAgent(context, context.packageName)
    }

    private val isOnlyContent: Boolean
        get() =
            currentAdTagUrl.isNullOrEmpty() || imaRequestBuilder.onlyContent

    private var listener: Player.Listener? = null
    private var adEventListener: CoolPlayAdListener = imaRequestBuilder.adsLoadListener.also {
        it.channel = channel
        "设置AdEventListener $channel valueChannel:${it.channel}".print(TAG)
    }

    private var mHttpDataSourceFactory: HttpDataSource.Factory? = null
    private var mCache: Cache? = null
    private val cacheDataSourceFactory: DataSource.Factory
        get() {
            if (mCache == null) {
                mCache = newCache()
            }
            return CacheDataSource.Factory()
                .setCache(mCache!!)
                .setUpstreamDataSourceFactory(dataSourceFactory)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        }

    private fun newCache(): Cache {
        return SimpleCache(
            File(context.externalCacheDir, "cp-video-cache"),  //缓存目录
            LeastRecentlyUsedCacheEvictor(CoolPlaySdk.cacheSize),  //缓存大小，默认512M，使用LRU算法实现
            StandaloneDatabaseProvider(context)
        )
    }

    private val dataSourceFactory: DataSource.Factory
        get() = DefaultDataSource.Factory(context, httpDataSourceFactory)
    private val httpDataSourceFactory: DataSource.Factory
        get() {
            if (mHttpDataSourceFactory == null) {
                mHttpDataSourceFactory = DefaultHttpDataSource.Factory()
                    .setUserAgent(mUserAgent)
                    .setAllowCrossProtocolRedirects(true)
            }
            return mHttpDataSourceFactory!!
        }

    private fun getMediaSourceFactory() =
        DefaultMediaSourceFactory(
            if (imaRequestBuilder.cache) {
                cacheDataSourceFactory
            } else {
                dataSourceFactory
            }
        )

    fun setCurrentAdTagUrl(adTagUrl: String?) {
        currentAdTagUrl = adTagUrl
    }


    private var imaSdkSettings: ImaSdkSettings? = null

    override fun loadAd() {
        "loadAd channel $channel isVMap${imaRequestBuilder.isVMap} 开始播放广告".print(TAG) // 确保 channel 在这里有值
        imaRequestBuilder.onAdsLoading(channel)

        playerView = adEventListener.attachPlayer(context)
            ?: ClLayoutPlayerBinding.inflate(LayoutInflater.from(context)).root

        playerView?.apply {
            "player ready".print(TAG)
            val layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            if (!imaRequestBuilder.isVMap) {
                useController = false
            }
            imaRequestBuilder.adContainer.also {
                // 禁止穿透
                it.isClickable = true
                // 如果是TV 设置交代呢
                if (CoolPlaySdk.isTVUiMode) {
                    it.isFocusable = true
                    it.isFocusableInTouchMode = true
                    it.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
                }
                it.addView(this, layoutParams)
            }
            imaAdsLoader =
                ImaAdsLoader.Builder(context)
                    .setDebugModeEnabled(CoolPlaySdk.isDebug).setAdEventListener { adEvent ->
                        adEventListener.onAdEvent(adEvent)
                        when (adEvent.type) {
                            AdEventType.CONTENT_PAUSE_REQUESTED -> {
                                // 内容暂停 恢复广告
                                upDateVolume(true)
                            }

                            AdEventType.CONTENT_RESUME_REQUESTED -> {
                                // 广告暂停,恢复内容
                                upDateVolume(false)
                            }

                            else -> {}
                        }
                    }.setAdErrorListener { error ->
                        "onAdError ${error.error}".print(TAG)
                        // 当加载或播放广告时引发的错误事件。
                        val msg = error.error.toString()
                        val map = hashMapOf("msg" to msg, "vast" to (currentAdTagUrl ?: ""))
                        adEventListener.onAdError(Gson().toJson(map))

                    }.setImaSdkSettings(getImaSdkSettings())
                    .setVideoAdPlayerCallback(object : VideoAdPlayerCallback {
                        override fun onAdProgress(p0: AdMediaInfo, p1: VideoProgressUpdate) {}

                        override fun onBuffering(p0: AdMediaInfo) {}

                        override fun onContentComplete() {
                            "onContentComplete".print(TAG)
                        }

                        override fun onEnded(p0: AdMediaInfo) {
                            "onEnded".print(TAG)
                        }

                        override fun onError(p0: AdMediaInfo) {
                            "onError ${p0.url}".print(TAG)
                        }

                        override fun onLoaded(p0: AdMediaInfo) {
                            "onLoaded ${p0.url}".print(TAG)
                        }

                        override fun onPause(p0: AdMediaInfo) {
                            "onPause ${p0.url}".print(TAG)
                        }

                        override fun onPlay(p0: AdMediaInfo) {
                            "onPlay ${p0.url}".print(TAG)
                            adEventListener.onCompleteAd(p0.url)
                        }

                        override fun onResume(p0: AdMediaInfo) {
                            "onResume ${p0.url}".print(TAG)
                        }

                        override fun onVolumeChanged(p0: AdMediaInfo, p1: Int) {}
                    }).apply {
                        val adPreloadTimeoutMs = imaRequestBuilder.adPreloadTimeoutMs
                        if (adPreloadTimeoutMs > 0) {
                            setAdPreloadTimeoutMs(adPreloadTimeoutMs)
                        }
                        "enableFocusSkipButton:${imaRequestBuilder.enableFocusSkipButton}".print(TAG)
                        setFocusSkipButtonWhenAvailable(imaRequestBuilder.enableFocusSkipButton)
                        if (imaRequestBuilder.mLoadVideoTimeout > 0) {
                            setMediaLoadTimeoutMs(imaRequestBuilder.mLoadVideoTimeout)
                        }
                        val mVastLoadTimeoutMs = imaRequestBuilder.requestAdTimeOut.toInt()
                        if (mVastLoadTimeoutMs > 0) {
                            setVastLoadTimeoutMs(mVastLoadTimeoutMs)
                        }
                        val mBitrate = imaRequestBuilder.bitrate
                        if (mBitrate > 0) {
                            setMaxMediaBitrate(mBitrate)
                        }
                        imaRequestBuilder.mimeTypes?.also {
                            if (it.isNotEmpty()) {
                                setAdMediaMimeTypes(it)
                            }
                        }
                    }
                    .build()

            initializePlayer()
        } ?: run {
            "playerView is null".print(TAG)
        }
    }

    private fun initializePlayer() {
        isInitializer = true
        playerView?.apply {   // 创建并设置媒体源工厂
            val defaultMediaSourceFactory = getMediaSourceFactory()

            defaultMediaSourceFactory.setLocalAdInsertionComponents(
                { imaAdsLoader }, this
            )
            exoPlayer =
                ExoPlayer.Builder(context).setMediaSourceFactory(defaultMediaSourceFactory)
                    .setRenderersFactory(DefaultRenderersFactory(context).also {
                        it.setEnableDecoderFallback(true) // 启用解码器回退机制
                            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON) // 启用扩展解码
                    })

                    .setDeviceVolumeControlEnabled(true)
                    .build()
            listener = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    "onIsPlayingChanged $isPlaying".print(TAG)
                    val isPlayingAd = isPlayingAd()
                    if (!isPlayingAd) {
                        if (isPlaying) {
                            adEventListener.onResume()
                        } else {
                            adEventListener.onPause()
                        }
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    super.onPlayerError(error)
                    "onPlayerError $error".print(TAG)
                    adEventListener.onAdError(error.message ?: "onPlayerError")
                    adEventListener.onError()
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    super.onPlaybackStateChanged(playbackState)
                    "onPlaybackStateChanged $playbackState--isPlayingAd:${isPlayingAd()}".print(
                        TAG
                    )
                    when (playbackState) {
                        Player.STATE_READY -> {
                            val isPlayingAd = isPlayingAd()
                            // 内容暂停 恢复广告
                            upDateVolume(isPlayingAd)
                            // 播放开始
                            if (isPlayingAd) {
                                adEventListener.onPlayAd()
                            } else {
                                adEventListener.onPlay()
                            }
                        }

                        Player.STATE_ENDED -> {
                            val isPlayingAd = isPlayingAd()
                            // 播放开始
                            if (!isPlayingAd) {
                                adEventListener.onComplete()
                            }
                        }

                        else -> {}
                    }
                }
            }
            exoPlayer?.addListener(listener!!)
            imaAdsLoader?.setPlayer(exoPlayer)
            player = exoPlayer
            playerView?.imaAdsLoader = imaAdsLoader
            updateControlComponent()
            startAd()
        }
    }

    private fun getImaSdkSettings(): ImaSdkSettings {
        if (imaSdkSettings == null) {
            imaSdkSettings = ImaSdkFactory.getInstance().createImaSdkSettings()
        }
        return imaSdkSettings!!
    }

    /**
     * //静音 0、全部  1、广告静音 2 全部开启声音
     */
    private fun upDateVolume(playingAd: Boolean) {
        when (val videoMuted = imaRequestBuilder.mVideoMute) {
            0, 2 -> {
                setMuted(videoMuted == 0)
            }

            1 -> {
                if (playingAd) {
                    setMuted(true)
                } else {
                    setMuted(false)
                }
            }
        }

    }

    private fun isPlayingAd(): Boolean {
        val player = playerView?.player
        return player != null && player.isCommandAvailable(Player.COMMAND_GET_CURRENT_MEDIA_ITEM)
                && player.isPlayingAd
                && player.playWhenReady
    }

    private fun setMuted(muted: Boolean) {
        "setMuted $muted".print(TAG)
        exoPlayer?.apply {
            if (availableCommands.contains(Player.COMMAND_SET_VOLUME)) {
                exoPlayer?.volume = if (muted) 0f else 1f
            }
        }
    }


    private fun startAd() {
        "isOnlyContent:$isOnlyContent".print(TAG)
        imaRequestBuilder.adContainer.post {
            val mediaItem = MediaItem.Builder().setUri(imaRequestBuilder.contentVideoUrl).apply {
                //只播放视频
                if (!isOnlyContent) {
                    setAdsConfiguration(
                        MediaItem.AdsConfiguration.Builder(Uri.parse(parseAdTagUrl(currentAdTagUrl)))
                            .build()
                    )
                }
            }.build()
            exoPlayer?.setMediaItem(mediaItem)
            exoPlayer?.prepare()
            exoPlayer?.playWhenReady = true
        }
    }

    private fun parseAdTagUrl(adTagUrl: String?): String? {
        val width = imaRequestBuilder.adContainer.width
        val height = imaRequestBuilder.adContainer.height
        val gaId = CoolPlaySdk.gaid
        val isLat = CoolPlaySdk.isLat
        var result = adTagUrl ?: return null
        result = result.replace("%%ADVERTISING_IDENTIFIER_PLAIN%%", gaId ?: "")
            .replace("%%ADVERTISING_IDENTIFIER_IS_LAT%%", "$isLat")
            .replace("%%WIDTH%%", width.toString())
            .replace("%%HEIGHT%%", height.toString())
            .replace(
                "%%ADVERTISING_IDENTIFIER_TYPE%%",
                if (gaId?.trim().isNullOrEmpty()) "0" else "1"
            )
        "real url:$result".print(TAG)
        return result
    }

    /**
     * 保存视频的位置，无论是内容还是广告。可以在应用暂停时调用，例如。
     */
    override fun pause() {
        releasePlayer()
    }

    private fun releasePlayer() {
        if (!isInitializer) return
        isInitializer = false
        if (playerView != null) {
            playerView!!.onPause()
        }
        imaAdsLoader?.setPlayer(null)
        exoPlayer?.pause()
    }

    /**
     * 恢复之前保存的视频进度位置。可以在应用恢复时调用。
     */
    override fun resume() {
        if (isInitializer) return
        isInitializer = true
        if (playerView != null) {
            imaAdsLoader?.setPlayer(exoPlayer)
            playerView!!.onResume()
            exoPlayer?.play()
        }
    }


    /** 销毁播放器。  */
    override fun release() {
        if (isReleased) return
        isReleased = true
        "release start $channel".print(TAG)
        imaAdsLoader?.setPlayer(null)
        imaAdsLoader?.release()
        imaAdsLoader = null
        try {
            Handler(Looper.getMainLooper()).post {
                "release player $channel".print(TAG)
                playerView?.background = null
                listener?.let { exoPlayer?.removeListener(it) }
                exoPlayer?.stop()
                exoPlayer?.clearMediaItems()
                exoPlayer?.release()
                exoPlayer = null
                playerView?.onPause()
                playerView?.player = null
                imaRequestBuilder.adContainer.removeView(playerView)
                playerView = null
                mCache?.release()
                mCache = null
                Runtime.getRuntime().gc()
            }
        } catch (e: Exception) {
            e.message?.print(TAG)
        }

        //上报广告事件
        adEventListener.uploadEvent()
        "release end $channel".print(TAG)
    }

    companion object {
        private const val TAG = "VideoPlayerController"
    }
}
