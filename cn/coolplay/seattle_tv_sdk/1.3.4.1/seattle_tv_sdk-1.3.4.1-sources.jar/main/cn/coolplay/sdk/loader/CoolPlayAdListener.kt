package cn.coolplay.sdk.loader

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.annotation.KeepMember
import cn.coolplay.sdk.player.ClPlayerView
import cn.coolplay.sdk.utils.print
import com.google.ads.interactivemedia.v3.api.Ad
import com.google.ads.interactivemedia.v3.api.AdErrorEvent
import com.google.ads.interactivemedia.v3.api.AdErrorEvent.AdErrorListener
import com.google.ads.interactivemedia.v3.api.AdEvent
import com.google.ads.interactivemedia.v3.api.AdEvent.AdEventListener
import com.google.ads.interactivemedia.v3.api.AdEvent.AdEventType

/**
 * 统一控制不同平台的广告播放控制
 */
@KeepMember
interface CoolBaseControl {

    var channel: String

    fun pause()

    fun release()

    fun resume()

    fun loadAd()

    fun isPlaying(): Boolean {
        return false
    }
}


/** 视频播放主要事件通知接口。  */
@KeepMember
interface CoolPlayAdCallback {

    /** 当前视频从头开始播放时调用。  */
    fun onPlay() {}
    fun onPlayAd() {}

    fun onCompleteAd(url: String) {}

    /** 当前视频暂停播放时调用。  */
    fun onPause() {}

    /** 当前视频从暂停状态恢复播放时调用。  */
    fun onResume() {}

    /** 当前视频播放到结尾时调用。  */
    fun onComplete() {}

    /** 视频播放过程中发生错误时调用。  */
    fun onError() {}

    //广告播放错误
    fun onAdError(msg: String) {}

    //请求广告前置加载
    fun onLoading(channel: String) {}

    /**
     *  播放广告事件回调
     */
    fun onAdEvent(event: AdEvent) {}

    //playerView
    @OptIn(UnstableApi::class)
    fun attachPlayer(context: Context): ClPlayerView? {
        return null
    }

}

//ima 广告和内容监听
@Keep
open class CoolPlayAdListener(
    private var label: String? = null,
    private var commonPrams: HashMap<String, Any> = hashMapOf(),
    private val adListener: CoolPlayAdCallback? = null,
) : AdEventListener, AdErrorListener, CoolPlayAdCallback {

    private var params = hashMapOf<String, Any>()

    private val adInfo = StringBuilder()

    var channel: String? = null
        set(value) {
            field = value
            channel?.let {
                params["channel"] = it
            }
            "设置channel $channel".print(TAG)
        }

    init {
        initParams()
    }

    private fun initParams() {
        reset()
    }

    open fun reset() {
        adInfo.clear()
        params.clear()
        params.putAll(commonPrams)
        label?.let {
            params["label"] = it
        }
    }

    open fun addAdInfo(info: String) {
        if (adInfo.isNotEmpty()) {
            adInfo.append(",")
        }
        adInfo.append(info)
    }

    override fun onAdEvent(event: AdEvent) {
        if (event.type != AdEventType.AD_PROGRESS) {
            "事件${event.type}".print("onAdEvent")
            addAdInfo(event.type.name)
        }
        adListener?.onAdEvent(event)
        when (event.type) {

            AdEventType.STARTED -> {
                onAdStarted(event.ad)
            }

            AdEventType.PAUSED -> {
                onAdPaused(event.ad)
            }

            AdEventType.RESUMED -> {
                onAdResumed(event.ad)
            }

            AdEventType.COMPLETED -> {
                onAdCompleted(event.ad)
            }

            AdEventType.ALL_ADS_COMPLETED -> {
                onAllAdCompleted(event.ad)
            }

            AdEventType.CLICKED -> {
                onAdClick(event.ad)
            }

            AdEventType.SKIPPED -> {
                onSkip(event.ad)
            }

            else -> {}
        }
    }

    open fun onAdClick(ad: Ad?) {
        "广告被点击了".print(TAG)
        val params = hashMapOf<String, Any>().apply {
            putAll(params)
            ad?.adId?.let {
                this["adId"] = it
            }
        }
        if (params.isNotEmpty()) {
            CoolPlaySdk.postDeviceData(params, "AdEventClicked")
        }
    }


    open fun onAdStarted(ad: Ad?) {
        "播放广告开始$label".print(TAG)
        val params = hashMapOf<String, Any>().apply {
            putAll(params)
            ad?.adId?.let {
                this["adId"] = it
            }
        }
        if (params.isNotEmpty()) {
            CoolPlaySdk.postDeviceData(params, "AdEventStarted")
        }
    }

    private fun onAdPaused(ad: Ad?) {
        "播放广告暂停$label adId:${ad?.adId}".print(TAG)
    }

    private fun onAdResumed(ad: Ad?) {
        "播放广告继续 adId:${ad?.adId}".print(TAG)
    }

    open fun onAdCompleted(ad: Ad?) {
        "播放广告完毕$label".print(TAG)
        val params = hashMapOf<String, Any>().apply {
            putAll(params)
            ad?.adId?.let {
                this["adId"] = it
            }
        }
        CoolPlaySdk.postDeviceData(params, "AdEventCompleted")
    }

    open fun onAllAdCompleted(ad: Ad?) {
        "所有广告播放完毕$label".print(TAG)
        val params = hashMapOf<String, Any>().apply {
            putAll(params)
            ad?.adId?.let {
                this["adId"] = it
            }
        }
        CoolPlaySdk.postDeviceData(params, "AdEventAllCompleted")
        uploadEvent()
    }

    open fun onSkip(ad: Ad?) {
        "播放广告跳过$label".print(TAG)
        val params = hashMapOf<String, Any>().apply {
            putAll(params)
            ad?.adId?.let {
                this["adId"] = it
            }
        }
        CoolPlaySdk.postDeviceData(params, "AdEventSkip")
    }

    override fun onAdError(adErrorEvent: AdErrorEvent) {
        onAdError(adErrorEvent.error.message)
    }

    override fun onAdError(msg: String) {
        "播放广告失败${msg} channel:${channel} $params".print(TAG)
        val params = hashMapOf<String, Any>().apply {
            putAll(params)
            this["error"] = msg
        }
        CoolPlaySdk.postDeviceData(params, "AdEventFailed")
        adListener?.onAdError(msg)
    }

    override fun onPlay() {
        "播放内容开始$label".print(TAG)
        adListener?.onPlay()
    }

    override fun onPlayAd() {
        "播放广告开始$label".print(TAG)
        adListener?.onPlayAd()
    }


    override fun onCompleteAd(url: String) {
        "播放广告Url$label".print(TAG)
        val params = hashMapOf<String, Any>().apply {
            putAll(params)
            this["adUrl"] = url
        }
        CoolPlaySdk.postDeviceData(params, "onCompleteAdUrl")
        adListener?.onCompleteAd(url)
    }

    override fun onPause() {
        "播放内容暂停$label".print(TAG)
        adListener?.onPause()
    }


    override fun onResume() {
        "播放内容恢复$label".print(TAG)
        adListener?.onResume()
    }

    override fun onComplete() {
        "播放内容完毕$label".print(TAG)
        adListener?.onComplete()
    }

    override fun onError() {
        "播放内容错误$label".print(TAG)
        adListener?.onError()
    }

    override fun onLoading(channel: String) {
        "加载中$label".print(TAG)
        adListener?.onLoading(channel)
    }

    fun uploadEvent() {
        if (adInfo.isEmpty()) {
            return
        }
        "上报广告事件$adInfo".print(TAG)
        val params = hashMapOf<String, Any>().apply {
            putAll(params)
            this["adInfo"] = adInfo.toString()
        }
        adInfo.clear()
        CoolPlaySdk.postDeviceData(params, "AdAllEvent")
    }

    @OptIn(UnstableApi::class)
    override fun attachPlayer(context: Context): ClPlayerView? {
        return adListener?.attachPlayer(context)
    }

    companion object {
        private const val TAG = "VideoPlayerListener"
    }

}