package cn.coolplay.sdk.bean

import android.content.Context
import cn.coolplay.sdk.RealAdCoolPlay
import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.loader.adapter.BaseAdAdapter
import cn.coolplay.sdk.utils.print


@Keep
data class CoolPlayBuilder(
    val context: Context,
    val clientId: String,
    val clientSecret: String,
    val packageName: String? = null,
    var testMode: Boolean = false,
    var deviceID: String? = null,
    val gaid: String? = null,
    val isLat: Int = 0,
    var isDebug: Boolean = false,
    var cacheSize: Long = 512 * 1024 * 1024,
    var globalLogTag: String = "CoolPlaySdk",
    val grantType: String = "client_credentials",
    val isTV: Boolean = true,
    var initStatusCallBack: (Int, String?) -> Unit = { _, _ -> }
) {

    fun build(): RealAdCoolPlay {
        return RealAdCoolPlay(
            this
        )
    }

}

@Keep
data class WhaleTvBuilder(
    val context: Context,
    val buildType: String? = "prod",
    val deviceTypeValue: String,
    val brandId: String,
    val productId: String,
    val mac: String,
    val functionType: String,
    val terminalType: String,
    val sceneId: String,
    val saasUrl: String,
    val isAdLogEnabled: Boolean? = false,
    val dpSwitch: Boolean? = true,
    val uiType: String = "aosp-stm-2025"
) {

    fun build(): BaseAdAdapter? {
        try {
            // Full class names used for constructor args so the LINT rule triggers if any of them move.
            val clazz = Class.forName("cn.coolplay.whale.WhaleTvAdapter")
            val constructor = clazz.getConstructor(WhaleTvBuilder::class.java)
            val instance = constructor.newInstance(this)
            return instance as? BaseAdAdapter
        } catch (e: Exception) {
            "whaleTv init fail $e".print()
        }
        return null
    }

}

@Keep
data class AirMobiBuilder(
    val context: Context,
) {

    fun build(): BaseAdAdapter? {
        try {
            val clazz = Class.forName("cn.coolplay.airmobi.AirMobiAdapter")
            val constructor = clazz.getConstructor(AirMobiBuilder::class.java)
            val instance = constructor.newInstance(this)
            return instance as? BaseAdAdapter
        } catch (e: Exception) {
            "AirMobi init fail $e".print()
        }
        return null
    }

}