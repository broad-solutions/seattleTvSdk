package cn.coolplay.sdk.player

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.webkit.WebView
import androidx.annotation.Keep
import androidx.core.view.children
import androidx.media3.common.Player.COMMAND_GET_CURRENT_MEDIA_ITEM
import androidx.media3.exoplayer.ima.ImaAdsLoader
import androidx.media3.ui.PlayerControlView
import androidx.media3.ui.PlayerView
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.utils.print


@SuppressLint("UnsafeOptInUsageError")
@Keep
open class ClPlayerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : PlayerView(context, attrs, defStyleAttr), ViewTreeObserver.OnGlobalFocusChangeListener {

    open var imaAdsLoader: ImaAdsLoader? = null
    open var controlView: PlayerControlView? = null
    open var adWebVIew: WebView? = null
    private var lastFocusView: String? = null

    private var viewRetryNum = 0
    open val videoController: VideoController?
        get() =
            controlView?.children?.find { it is VideoController } as VideoController?


    init {
        initView()
    }

    private fun initView() {
        "initView isTv:${CoolPlaySdk.isTVUiMode}".print("MyPlayerView")
        if (CoolPlaySdk.isTVUiMode) {
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            viewTreeObserver.addOnGlobalFocusChangeListener(this)
        }
    }


    override fun addView(child: View?, index: Int, params: ViewGroup.LayoutParams?) {
        "addView ${child?.javaClass?.name}".print("MyPlayerView")
        if (child is PlayerControlView) {
            controlView = child
            controlView?.isAnimationEnabled = false
        }
        super.addView(child, index, params)
    }

    /**
     * 添加控制组件，最后面添加的在最下面，合理组织添加顺序，可让ControlComponent位于不同的层级
     */
    fun updateControlComponent() {
        videoController?.also {
            it.setPlayerController(controlView, it, player)
        } ?: run {
            "videoController is null".print("MyPlayerView")
        }
    }


    override fun onGlobalFocusChanged(oldFocus: View?, newFocus: View?) {
        if (newFocus is WebView) {
            adWebVIew = newFocus
        }
        "onGlobalFocusChanged old:${oldFocus?.javaClass?.name} new:${newFocus?.javaClass?.name}".print(
            "MyPlayerView"
        )
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (CoolPlaySdk.isDebug) {
            viewTreeObserver.removeOnGlobalFocusChangeListener(this)
        }
        videoController?.removeAllControlComponent()
        controlView = null
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (player != null
            && player!!.isCommandAvailable(COMMAND_GET_CURRENT_MEDIA_ITEM)
            && player!!.isPlayingAd
        ) {
            val dispatcher = super.dispatchKeyEvent(event)
            if (event.action == KeyEvent.ACTION_UP) {
                this.post {
                    checkFocusedElement()
                }
            }
            return dispatcher
        }
        return super.dispatchKeyEvent(event);
    }

    // 检查当前获取焦点的元素
    private fun checkFocusedElement() {
        val jsCode = """
        (function() {
            var activeElement = document.activeElement;
            if (activeElement) {
                return JSON.stringify({
                    tagName: activeElement.tagName,
                    id: activeElement.id || '',
                    className: activeElement.className || '',
                    innerText: activeElement.innerText ? activeElement.innerText.substring(0, 50) : ''
                });
            }
            return '{}';
        })();
    """.trimIndent()

        adWebVIew?.evaluateJavascript(jsCode) { result ->
            try {
                if (result != "{}") {
                    "Focused element result: $result".print("ClPlayerView")
                    "Focused element lastFocusView: $lastFocusView".print("ClPlayerView")
                    if (lastFocusView != result) {
                        lastFocusView = result
                    } else {
                        viewRetryNum = 0
                        if (lastFocusView?.contains("vastIcon") == true) {
                            imaAdsLoader?.focusSkipButton()
                            lastFocusView = null
                            viewRetryNum = 0
                        } else {
                            viewRetryNum += 1
                            if (viewRetryNum >= 2) {
                                imaAdsLoader?.focusSkipButton()
                                lastFocusView = null
                                viewRetryNum = 0
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}