package cn.coolplay.sdk

import android.annotation.SuppressLint
import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.bean.AirMobiBuilder
import cn.coolplay.sdk.bean.CoolPlayBuilder
import cn.coolplay.sdk.bean.WhaleTvBuilder
import cn.coolplay.sdk.loader.AdRequestBuilder
import cn.coolplay.sdk.loader.CoolBaseControl
import cn.coolplay.sdk.loader.CoolPlayAdControl
import cn.coolplay.sdk.loader.adapter.BaseAdAdapter
import cn.coolplay.sdk.report.UploadEvent
import cn.coolplay.sdk.utils.print
import kotlinx.coroutines.launch

@Keep
enum class AdImaType {
    SECTION, BANNER, SPLASH
}

@Keep
enum class AdChannelType {
    GOOGLE,
    WhaleTV,
    AirMobi
}

@SuppressLint("UnsafeOptInUsageError")
/**
 * 统一管理广告
 */
@Keep
object CoolPlaySdk {
    private var coolPlayAd: RealAdCoolPlay? = null
    var isTVUiMode: Boolean = true
    val isDebug get() = coolPlayAd?.isDebug ?: false
    val testMode get() = coolPlayAd?.testMode ?: false
    val globalLogTag get() = coolPlayAd?.globalLogTag ?: "CoolPlaySdk"

    @JvmStatic
    val deviceID: String? get() = coolPlayAd?.deviceID

    @JvmStatic
    val versionName: String? get() = coolPlayAd?.versionName
    val packageName: String get() = coolPlayAd?.packageName ?: ""

    private var whaleTvSdk: BaseAdAdapter? = null
    private var airMobiSdk: BaseAdAdapter? = null
    const val ON_INIT_TOKEN_SUCCESS: Int = 0
    const val ON_INIT_TOKEN_FAIL: Int = -1
    const val ON_SYNC_AD_CONFIG_SUCCESS: Int = 2
    const val ON_SYNC_AD_CONFIG_FAIL: Int = 3
    const val EMPTY_CHANNEL: String = "emptyChannel"

    fun init(
        coolPlayBuilder: CoolPlayBuilder,
        whaleTvBuilder: WhaleTvBuilder? = null,
        airMobiBuilder: AirMobiBuilder? = null,
    ) {
        coolPlayAd = coolPlayBuilder.build()
        whaleTvSdk = whaleTvBuilder?.build()
        "whaleTvSdk ${whaleTvSdk == null}".print()
        airMobiSdk = airMobiBuilder?.build()
        "airMobiSdk ${airMobiSdk == null}".print()

    }

    // 检查是否初始化 whaltv 或者 airMobi
    fun checkInit(channelType: String) = when (channelType) {
        AdChannelType.WhaleTV.name.lowercase() -> whaleTvSdk != null
        AdChannelType.AirMobi.name.lowercase() -> airMobiSdk != null
        else -> coolPlayAd != null
    }


    fun loadAd(adRequestBuilder: AdRequestBuilder) =
        coolPlayAd?.loadAd(adRequestBuilder)


    fun destroy() {
        coolPlayAd?.destroy() // 假设 RealAdCoolPlay 有一个 destroy 方法来释放资源
        coolPlayAd = null
    }

    fun postData(
        data: Any,
        eventName: String,
        eventType: String = "Insight"
    ) = UploadEvent.postData(data, eventName, eventType).also {
        upLoadEvent(it)
    }


    fun postDeviceData(
        data: String,
        eventName: String,
        eventType: String = "Insight"
    ) = UploadEvent.postData(mapOf("deviceId" to deviceID, "data" to data), eventName, eventType)
        .also {
            upLoadEvent(it)
        }

    fun postDeviceData(
        data: Map<String, Any>,
        eventName: String,
        eventType: String = "Insight"
    ) {
        val params = data.toMutableMap()
        deviceID?.also {
            params["deviceId"] = it
        }
        if (!versionName.isNullOrEmpty()) {
            params["versionName"] = versionName ?: ""
        }
        params["testMode"] = testMode

        "map=$params".print("postDeviceData")
        UploadEvent.postData(
            params,
            eventName,
            eventType
        )
            .also {
                upLoadEvent(it)
            }
    }

    suspend fun syncToken(): String? {
        return coolPlayAd?.syncToken()
    }

    //上传数据
    fun upLoadEvent(params: Map<String, Any>) =
        coolPlayAd?.launch {
            val token = syncToken()
            if (!token.isNullOrEmpty()) {
                UploadEvent.uploadData(params)
            }
        }

    fun initController(
        coolPlayAdControl: CoolPlayAdControl,
        channel: String,
        unitViewId: String
    ): CoolBaseControl {
        ("initController channel $channel").print()
        return when (channel.lowercase()) {
            AdChannelType.WhaleTV.name.lowercase() -> {
                whaleTvSdk!!.loadAd(coolPlayAdControl, channel, unitViewId)
            }

            else -> {
                ("airMobiSdk $airMobiSdk").print()
                airMobiSdk!!.loadAd(coolPlayAdControl, channel, unitViewId)
            }
        }

    }
}
