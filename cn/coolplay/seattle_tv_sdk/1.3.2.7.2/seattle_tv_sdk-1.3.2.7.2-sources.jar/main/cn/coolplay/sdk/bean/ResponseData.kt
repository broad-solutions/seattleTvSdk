package cn.coolplay.sdk.bean

import cn.coolplay.sdk.annotation.Keep

@Keep
data class ResponseData(
    val code: Int,
    val msg: String,
    val data: Data?
)

@Keep
data class Data(
    val strategy: Int,
    val defaultVideoForAd: VideoForAd?,
    val channelTypes: String?,
    var lastTime: Long,
    var expire: Long,
    val adList: List<DataItem>
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Data) return false

        if (strategy != other.strategy) return false
        if (defaultVideoForAd != other.defaultVideoForAd) return false
        if (channelTypes != other.channelTypes) return false
        if (expire != other.expire) return false
        if (adList != other.adList) return false

        return true
    }

    override fun hashCode(): Int {
        var result = strategy
        result = 31 * result + (defaultVideoForAd?.hashCode() ?: 0)
        result = 31 * result + (channelTypes?.hashCode() ?: 0)
        result = 31 * result + expire.hashCode()
        result = 31 * result + adList.hashCode()
        return result
    }
}

@Keep
data class VideoForAd(
    val url: String,
    val shortDramaId: String,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is VideoForAd) return false

        if (url != other.url) return false
        if (shortDramaId != other.shortDramaId) return false

        return true
    }

    override fun hashCode(): Int {
        var result = url.hashCode()
        result = 31 * result + shortDramaId.hashCode()
        return result
    }
}

@Keep
data class DataItem(
    val channelType: String,
    val packageName: String,
    val url: String,
    val adDisplayType: String,
    val playPosition: String,
    val otherParam: String?,
    val width: Int,
    val height: Int,
    val createTime: String,
    val updateTime: String?
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is DataItem) return false

        if (channelType != other.channelType) return false
        if (packageName != other.packageName) return false
        if (url != other.url) return false
        if (adDisplayType != other.adDisplayType) return false
        if (playPosition != other.playPosition) return false
        if (otherParam != other.otherParam) return false
        if (width != other.width) return false
        if (height != other.height) return false
        if (createTime != other.createTime) return false
        if (updateTime != other.updateTime) return false

        return true
    }

    override fun hashCode(): Int {
        var result = channelType.hashCode()
        result = 31 * result + packageName.hashCode()
        result = 31 * result + url.hashCode()
        result = 31 * result + adDisplayType.hashCode()
        result = 31 * result + playPosition.hashCode()
        result = 31 * result + (otherParam?.hashCode() ?: 0)
        result = 31 * result + width
        result = 31 * result + height
        result = 31 * result + createTime.hashCode()
        result = 31 * result + (updateTime?.hashCode() ?: 0)
        return result
    }
}

@Keep
data class TokenData(
    val access_token: String,
    val token_type: String,
    val expires_in: Int,
    val scope: String,
    val jti: String,
    var lastTime: Long
)