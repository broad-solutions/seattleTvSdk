package cn.coolplay.sdk.loader

import android.annotation.SuppressLint
import android.webkit.URLUtil
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.bean.Data
import cn.coolplay.sdk.bean.DataItem
import cn.coolplay.sdk.bean.VideoForAd
import cn.coolplay.sdk.loader.banner.BannerController
import cn.coolplay.sdk.loader.banner.BannerRequest
import cn.coolplay.sdk.loader.section.SectionController
import cn.coolplay.sdk.loader.section.SectionRequest
import cn.coolplay.sdk.loader.splash.SplashController
import cn.coolplay.sdk.loader.splash.SplashRequest
import cn.coolplay.sdk.utils.print
import java.util.LinkedList
import java.util.Queue
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("UnsafeOptInUsageError")
class CoolAdLoader(data: Data) {


    // 当前的广告类型的集合
    private var adTypeMapper: ConcurrentHashMap<String, HashMap<String, DataItem>>? = null

    // 广告列表
    private var adList: List<DataItem>? = null

    // 广告的策略
    private var strategy: Int = 0

    // 默认的广告地址
    private var defaultVideoForAd: VideoForAd? = null

    // 当前的渠道
    private var channelTypes: List<String>? = null
    private var channelTypesStack: Queue<String>? = null
    private var isReportNoVast: Boolean = false

    //记录Vast 类型
    private var channelVastTypesStack: Queue<String>? = null

    init {
        adList = data.adList
        strategy = data.strategy
        defaultVideoForAd = data.defaultVideoForAd
        channelTypes = (data.channelTypes?.split(",")?.toTypedArray() ?: arrayOf()).toList()

        // 获取广告类型的集合
        adTypeMapper = ConcurrentHashMap<String, HashMap<String, DataItem>>().apply {
            adList?.forEach { dataItem ->
                val innerMap = getOrPut(dataItem.adDisplayType) { HashMap() }
                innerMap[dataItem.channelType.lowercase()] = dataItem
                putIfAbsent(dataItem.adDisplayType, innerMap)
            }
        }
    }

    fun load(adRequestBuilder: AdRequestBuilder): CoolPlayAdControl? {
        if (adRequestBuilder.contentVideoUrl.isNullOrEmpty()) {
            adRequestBuilder.contentVideoUrl = defaultVideoForAd?.url ?: ""
        }
        // 获取广告类型的渠道集合
        val adTypeList = adTypeMapper?.get(adRequestBuilder.adImaType.name) ?: hashMapOf()
        if (adRequestBuilder.isVMap) {
            return loadVast(adRequestBuilder, adTypeList)
        }
        return load(adRequestBuilder, adTypeList)
    }

    //channel 统一 改为小写
    fun reset() {
        //获取广告类型的渠道集合
        if (channelTypesStack.isNullOrEmpty()) {
            channelTypesStack = LinkedList(channelTypes?.map { it.lowercase() } ?: arrayListOf())
        }

    }

    //只请求 vast
    private fun loadVast(
        adRequestBuilder: AdRequestBuilder,
        adTypeList: HashMap<String, DataItem>,
    ): CoolPlayAdControl? {
        if (channelVastTypesStack.isNullOrEmpty()) {
            //获取广告类型的渠道集合是URL 那么他应该是vast
            val channel =
                adTypeList.filter { URLUtil.isNetworkUrl(it.value.url) }.keys.map { it.lowercase() }
            channelVastTypesStack = LinkedList(channel)
        }

        // 这里是从数据集中获取的，所以不会出现不存在的情况 由于VMap 必须长驻留的 没有渠道也应该让对方显示
        "loadVast adType${adRequestBuilder.adImaType.name} vasts:${channelVastTypesStack!!.isEmpty()}".print(
            TAG
        )
        //没有配置vast 通知服务器
        if (channelVastTypesStack!!.isEmpty() && !isReportNoVast) {
            CoolPlaySdk.postDeviceData(
                mapOf("config" to adTypeList.keys.joinToString(",")), "NoVastConfig"
            )
        } else {
            isReportNoVast = false
        }
        val channel = channelVastTypesStack?.poll()

        return requestAd(
            adRequestBuilder, channel ?: CoolPlaySdk.EMPTY_CHANNEL, adTypeList[channel]
        )
    }


    //进行加载广告 去掉并行
    private fun load(
        adRequestBuilder: AdRequestBuilder,
        adTypeList: HashMap<String, DataItem>,
    ): CoolPlayAdControl? {
        if (adTypeList.isEmpty()) {
            "渠道为空".print(TAG)
            adRequestBuilder.adsLoadListener.onAdError("渠道为空")
            adRequestBuilder.adsLoadListener.onError()
            return null
        }
        val channel = channelTypesStack?.poll()
        if (channel == null) {
            "暂无广告".print(TAG)
            adRequestBuilder.adsLoadListener.onAdError("暂无广告")
            adRequestBuilder.adsLoadListener.onError()
            return null
        }
        adTypeList.keys.joinToString(",").print(TAG)
        adTypeList[channel]?.also {
            //先判断是否初始化
            val lastChannel = CoolPlaySdk.checkInit(channel)
            return if (lastChannel) {
                "load adType${adRequestBuilder.adImaType.name} channel:$channel 开始加载广告".print(
                    TAG
                )
                requestAd(adRequestBuilder, channel, it)
            } else {
                "渠道 '$channel' 没有初始化，继续下一个渠道".print(TAG)
                load(adRequestBuilder, adTypeList) // 递归尝试
            }
        }
        "渠道 '$channel' 没有对应的广告数据，继续下一个渠道".print(TAG)
        return load(adRequestBuilder, adTypeList) // 递归尝试下一个渠道

    }

    private fun requestAd(
        adRequestBuilder: AdRequestBuilder, channel: String, adItem: DataItem?
    ): CoolPlayAdControl? {
        "加载广告 ${adRequestBuilder.adImaType.name} $channel url:${adItem?.url}".print(TAG)
        var controller: CoolPlayAdControl? = null
        when (adRequestBuilder) {
            is SectionRequest -> {
                controller = SectionController(
                    adRequestBuilder, channel, adItem?.url,
                )
            }

            is BannerRequest -> {
                controller = BannerController(
                    adRequestBuilder, channel, adItem?.url,
                )
            }

            is SplashRequest -> {
                controller = SplashController(adRequestBuilder, channel, adItem?.url)
            }
        }
        controller?.also {
            it.loadAd()
        }
        return controller
    }

    companion object {
        const val TAG = "CoolAdLoader"
    }
}