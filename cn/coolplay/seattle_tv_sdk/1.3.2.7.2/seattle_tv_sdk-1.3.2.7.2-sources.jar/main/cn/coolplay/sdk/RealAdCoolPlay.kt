package cn.coolplay.sdk

import android.content.Context
import cn.coolplay.sdk.bean.CoolPlayBuilder
import cn.coolplay.sdk.bean.Data
import cn.coolplay.sdk.loader.AdRequestBuilder
import cn.coolplay.sdk.loader.CoolAdLoader
import cn.coolplay.sdk.task.SyncAdCongTask
import cn.coolplay.sdk.task.SyncTokenTask
import com.tencent.mmkv.MMKV
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.EmptyCoroutineContext

class RealAdCoolPlay(builder: CoolPlayBuilder) : IAdCoolPlay,
    CoroutineScope by CoroutineScope(EmptyCoroutineContext) {
    private val syncTokenTask = SyncTokenTask(this)
    private val syncAdConfigTask = SyncAdCongTask(this)

    private val initCallBacks = builder.initStatusCallBack
    val testMode: Boolean = builder.testMode
    val isDebug: Boolean = builder.isDebug
    val packageName: String = builder.packageName ?: builder.context.packageName
    val versionName: String? = getVersionName(builder.context)
    val clientId: String = builder.clientId
    val clientSecret: String = builder.clientSecret
    val grantType: String = builder.grantType
    val globalLogTag = builder.globalLogTag
    val deviceID: String? = builder.deviceID

    private var adConfigData: Data? = null
    private var vastLoader: CoolAdLoader? = null
        get() {
            if (field == null) {
                field = CoolAdLoader(adConfigData!!)
            }
            return field
        }

    private var retryNum = 0
    private var token: String? = null

    private fun getVersionName(context: Context): String? =
        try {
            context.packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            e.printStackTrace()
            "no package:${packageName}"
        }

    init {
        MMKV.initialize(builder.context)
    }

    private fun syncAdInfo(init: (Boolean) -> Unit) {
        sycAdConfig {
            //代表初始化成功
            if (it) {
                retryNum = 0
                init.invoke(true)
            } else {
                retryNum++
                if (retryNum < 5) {
                    retry(init)
                } else {
                    init.invoke(false)
                }
            }
        }
    }

    private fun retry(init: (Boolean) -> Unit) {
        launch {
            delay(1000)
            syncAdInfo(init)
        }
    }

    suspend fun syncToken(): String? {
        val lastToken = syncTokenTask.execute()
        if (lastToken.isNullOrEmpty()) {
            return null
        }
        //避免重复回掉
        if (token != lastToken) {
            token = lastToken
            withContext(Dispatchers.Main) {
                initCallBacks.invoke(CoolPlaySdk.ON_INIT_TOKEN_SUCCESS, token)
            }
        }
        return lastToken
    }

    override fun sycAdConfig(block: (Boolean) -> Unit) {
        launch {
            val lastToken = syncToken()
            if (lastToken.isNullOrEmpty()) {
                withContext(Dispatchers.Main) {
                    initCallBacks.invoke(
                        CoolPlaySdk.ON_INIT_TOKEN_FAIL,
                        "sync retryNum=$retryNum token is null"
                    )
                    block.invoke(false)
                }
                return@launch
            }
            val data = syncAdConfigTask.execute()
            if (data == null) {
                withContext(Dispatchers.Main) {
                    initCallBacks.invoke(
                        CoolPlaySdk.ON_SYNC_AD_CONFIG_FAIL,
                        "sync retryNum=$retryNum adConfig is null"
                    )
                    block.invoke(false)
                }
                return@launch
            }
            //避免重复回掉
            if (adConfigData != data) {
                adConfigData = data
                vastLoader = null
                withContext(Dispatchers.Main) {
                    initCallBacks.invoke(
                        CoolPlaySdk.ON_SYNC_AD_CONFIG_SUCCESS,
                        "sync adConfig is ok"
                    )
                    block.invoke(true)
                }
            } else {
                withContext(Dispatchers.Main) {
                    //配置有新
                    block.invoke(true)
                }
            }
        }
    }


    override fun loadAd(adRequestBuilder: AdRequestBuilder) {
        //有配置去请求广告
        //重置参数
        var isRequestAd = false
        adRequestBuilder.adsLoadListener.reset()
        if (adConfigData != null) {
            isRequestAd = true
            vastLoader?.reset()
            adRequestBuilder.coolPlayAdControl = vastLoader?.load(adRequestBuilder)
        }
        syncAdInfo { init ->
            // 没有配置 请求后去请求广告
            if (!isRequestAd) {
                if (init) {
                    vastLoader?.reset()
                    adRequestBuilder.coolPlayAdControl = vastLoader?.load(adRequestBuilder)
                } else {
                    adRequestBuilder.adsLoadListener.onAdError("init fail")
                    //强制退出播放器
                    adRequestBuilder.adsLoadListener.onError()
                }
            }
        }
    }

    override fun destroy() {
        cancel()
    }


}