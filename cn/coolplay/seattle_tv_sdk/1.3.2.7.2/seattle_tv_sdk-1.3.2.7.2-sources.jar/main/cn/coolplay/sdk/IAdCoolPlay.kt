package cn.coolplay.sdk

import cn.coolplay.sdk.loader.AdRequestBuilder

interface IAdCoolPlay {

    fun sycAdConfig(block: (Boolean) -> Unit)
    fun loadAd(adRequestBuilder: AdRequestBuilder)
    fun destroy()

}