package cn.coolplay.sdk.loader.adapter

import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.loader.CoolBaseControl
import cn.coolplay.sdk.loader.CoolPlayAdControl

@Keep
interface BaseAdAdapter {

    fun loadAd(
        coolPlayAdControl: CoolPlayAdControl,
        channel: String,
        unitViewId: String
    ): CoolBaseControl
}