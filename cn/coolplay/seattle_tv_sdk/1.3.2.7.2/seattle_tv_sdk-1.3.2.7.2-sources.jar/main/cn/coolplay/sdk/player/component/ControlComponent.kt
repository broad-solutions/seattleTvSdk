package cn.coolplay.sdk.player.component

import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.PopupWindow
import androidx.annotation.Keep
import androidx.annotation.OptIn
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerControlView
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.player.VideoController

/**
 * 控制器中的控制组件
 * @param view 控件
 * @param tag 组件的tag
 */
@Keep
interface ControlComponent : Player.Listener, OnClickListener, PopupWindow.OnDismissListener {
    val view: View
    val tag: String

    /**
     * 将 控制器 传递到当前 ControlComponent 中
     * 注意：如需在此方法中访问 VideoViewControl 中的api，则需要确保 VideoController 已经设置到 VideoView 上
     */
    @OptIn(UnstableApi::class)
    fun attachController(
        controller: PlayerControlView?,
        videoController: VideoController,
        player: Player?
    )

    /**
     * 是否采用焦点模式：用于处理Component内部控件的操作模式
     *
     * @return
     */
    fun isTVUiMode(): Boolean {
        return CoolPlaySdk.isTVUiMode
    }

    /**
     * view 之间通信使用
     */
    fun postEvent(bundle: Bundle) {}

    /**
     *
     * @param
     */
    fun updateIsFullscreen(isFullscreen: Boolean) {}


    /**
     * 回调播放进度，1秒回调一次
     *
     * @param duration 视频总时长
     * @param position 播放进度
     * @param bufferedPosition 缓冲进度
     */
    fun onProgressChanged(duration: Long, position: Long, bufferedPosition: Long) {}

}