package cn.coolplay.sdk.loader.splash

import cn.coolplay.sdk.loader.CoolPlayAdControl

class SplashController(
    adRequestBuilder: SplashRequest,
    channel: String,
    unitViewId: String?,
) : CoolPlayAdControl(adRequestBuilder, channel, unitViewId)