package cn.coolplay.sdk.player

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import androidx.annotation.Keep
import androidx.core.view.children
import androidx.media3.ui.PlayerControlView
import androidx.media3.ui.PlayerView
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.utils.print


@SuppressLint("UnsafeOptInUsageError")
@Keep
open class ClPlayerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : PlayerView(context, attrs, defStyleAttr), ViewTreeObserver.OnGlobalFocusChangeListener {

    open var controlView: PlayerControlView? = null

    open val videoController: VideoController?
        get() =
            controlView?.children?.find { it is VideoController } as VideoController?


    init {
        initView()
    }

    private fun initView() {
        "initView isTv:${CoolPlaySdk.isTVUiMode}".print("MyPlayerView")
        if (CoolPlaySdk.isTVUiMode) {
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            if (CoolPlaySdk.isDebug) {
                viewTreeObserver.addOnGlobalFocusChangeListener(this)
            }
        }
    }


    override fun addView(child: View?, index: Int, params: ViewGroup.LayoutParams?) {
        "addView ${child?.javaClass?.name}".print("MyPlayerView")
        if (child is PlayerControlView) {
            controlView = child
            controlView?.isAnimationEnabled = false
        }
        super.addView(child, index, params)
    }

    /**
     * 添加控制组件，最后面添加的在最下面，合理组织添加顺序，可让ControlComponent位于不同的层级
     */
    fun updateControlComponent() {
        videoController?.also {
            it.setPlayerController(controlView, it, player)
        } ?: run {
            "videoController is null".print("MyPlayerView")
        }
    }


    override fun onGlobalFocusChanged(oldFocus: View?, newFocus: View?) {
        "onGlobalFocusChanged old:${oldFocus?.javaClass?.name} new:${newFocus?.javaClass?.name}".print(
            "MyPlayerView"
        )
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (CoolPlaySdk.isDebug) {
            viewTreeObserver.removeOnGlobalFocusChangeListener(this)
        }
        videoController?.removeAllControlComponent()
        controlView = null
    }
}