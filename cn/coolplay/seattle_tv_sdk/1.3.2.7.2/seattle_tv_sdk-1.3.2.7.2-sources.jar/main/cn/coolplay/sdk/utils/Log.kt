package cn.coolplay.sdk.utils

import android.util.Log
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.annotation.Keep

fun String.print(tag: String = "") {
    if (CoolPlaySdk.isDebug) {
        Log.e("${CoolPlaySdk.globalLogTag}:$tag", this)
    }
}