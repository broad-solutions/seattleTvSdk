package cn.coolplay.sdk.task

abstract class ITask<R> {
    abstract suspend fun execute(): R
}