package cn.coolplay.sdk.loader.banner

import cn.coolplay.sdk.loader.CoolPlayAdControl

class BannerController(
    adRequestBuilder: BannerRequest,
    channel: String,
    unitViewId: String?
) : CoolPlayAdControl(adRequestBuilder, channel, unitViewId)
