package cn.coolplay.sdk.player.component

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import androidx.annotation.Keep
import androidx.annotation.OptIn
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerControlView
import cn.coolplay.sdk.player.VideoController
import cn.coolplay.sdk.utils.print
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlin.coroutines.CoroutineContext

@UnstableApi
@Keep
abstract class BaseControlComponent @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr), ControlComponent, CoroutineScope {
    private val job = SupervisorJob()
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main + job

    open val layoutInflater: LayoutInflater get() = LayoutInflater.from(context)

    override val tag: String
        get() = "BaseControlComponent"

    override val view: View
        get() = this

    open var controller: PlayerControlView? = null

    open var videoController: VideoController? = null


    open var player: Player? = null
        set(value) {
            field = value
            "set player$value".print(tag)
        }

    @OptIn(UnstableApi::class)
    override fun attachController(
        controller: PlayerControlView?,
        videoController: VideoController,
        player: Player?
    ) {
        this.controller = controller
        this.videoController = videoController
        if (this.player == player) {
            return
        }
        this.player?.removeListener(this)
        this.player = player
        this.player?.addListener(this)
    }

    /**
     * 播放和暂停
     */
    /**
     * 播放和暂停
     */
    fun togglePlay() {
        player?.also {
            if (it.isPlaying) {
                it.pause()
            } else {
                it.play()
            }
        }
    }

    /**
     * 暂停播放
     */
    /**
     * 暂停播放
     */
    fun pause() {
        player?.also {
            it.pause()
        }
    }

    /**
     * 播放
     */
    /**
     * 播放
     */
    fun play() {
        player?.also {
            it.play()
        }
    }

    /**
     * 停止播放
     */
    /**
     * 停止播放
     */
    fun stop() {
        player?.also {
            it.stop()
        }
    }


    /**
     * @return true:调用了重播方法，false则表示未处理任何
     */
    /**
     * @return true:调用了重播方法，false则表示未处理任何
     */
    fun replay(resetPosition: Boolean = true) {
        player?.also {
            // 停止当前播放并重置播放位置
            it.stop()
            it.seekTo(if (resetPosition) 0 else it.currentPosition) // 回到起始位置
            // 重新准备播放器（如果之前设置了广告）
            it.prepare()
            // 开始播放
            it.play()
        }
    }

    override fun updateIsFullscreen(isFullscreen: Boolean) {
        controller?.updateIsFullscreen(isFullscreen)
    }

    /**
     * 横竖屏切换
     */
    /**
     * 横竖屏切换
     */
    fun toggleFullScreen() {
        controller?.also {
            updateIsFullscreen(!it.isFullyVisible)
        }
    }

    fun startFullScreen() {
        updateIsFullscreen(true)
    }

    fun stopFullScreen() {
        updateIsFullscreen(false)
    }


    fun isPlayingAd(): Boolean {
        return player != null && player!!.isCommandAvailable(Player.COMMAND_GET_CURRENT_MEDIA_ITEM) && player!!.isPlayingAd && player!!.playWhenReady
    }

    override fun onDismiss() {

    }

    override fun onClick(v: View?) {

    }
}