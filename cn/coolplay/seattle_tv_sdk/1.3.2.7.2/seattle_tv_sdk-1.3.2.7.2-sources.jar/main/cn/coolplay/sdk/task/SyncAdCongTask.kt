package cn.coolplay.sdk.task

import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.RealAdCoolPlay
import cn.coolplay.sdk.bean.Data
import cn.coolplay.sdk.bean.ResponseData
import cn.coolplay.sdk.http.Http.okHttpClient
import cn.coolplay.sdk.utils.Shares.adConfigInfo
import cn.coolplay.sdk.utils.Shares.authorInfo
import cn.coolplay.sdk.utils.print
import com.google.gson.Gson
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class SyncAdCongTask(private val adCoolPlay: RealAdCoolPlay) :
    ITask<Data?>() {
    companion object {
        const val TAG = "SyncAdCongTask"
    }

    private val sysAdUrl by lazy {
        val param = mutableMapOf("packageName" to adCoolPlay.packageName)
        if (CoolPlaySdk.testMode) {
            param["testMode"] = "true"
        }
        val paramStr = param.map { (key, value) ->
            "$key=$value"
        }.joinToString("&")
        "https://sdkapi.ci-ads.com/v1/advertising/content?".plus(paramStr)
    }

    private var lastTime = 0L
    private var adExpiredTime = 0L
    private val mutex = Mutex()

    init {
        adConfigInfo?.also {
            lastTime = it.lastTime
            adExpiredTime = it.expire
        }
    }

    override suspend fun execute(): Data? {
        return mutex.withLock {
            if (adConfigInfo == null || isAdConfigExpired()) {
                "同步广告配置信息".print(TAG)
                adConfigInfo = refreshAdConfigAsync()
            }
            adConfigInfo
        }
    }

    private suspend fun refreshAdConfigAsync(): Data? {
        return suspendCoroutine { continuation ->
            if (adCoolPlay.clientId.isEmpty() || adCoolPlay.clientSecret.isEmpty()) {
                continuation.resume(null)
            } else {
                fetchAdConfigAsync {
                    if (it == null) {
                        continuation.resume(null)
                    } else {
                        adConfigInfo = it
                        lastTime = it.lastTime
                        adExpiredTime = it.expire
                        continuation.resume(it)
                    }
                }
            }
        }
    }

    private fun fetchAdConfigAsync(resultCall: (Data?) -> Unit) {
        val request = Request.Builder()
            .url(sysAdUrl)
            .header("Authorization", "Bearer ${authorInfo?.access_token}").build()
        "adList request data: ${request.url}".print("adList")
        okHttpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                "fetchAdConfigAsync adList response data: ${e.message}".print(TAG)
                resultCall.invoke(null)
            }

            override fun onResponse(call: Call, response: Response) {
                runCatching {
                    "fetchAdConfigAsync adList response data: $response".print(TAG)
                    if (!response.isSuccessful) {
                        authorInfo = null
                        resultCall.invoke(null)
                        return
                    }
                    val json = response.body?.string()
                    "fetchAdConfigAsync adList response json: $json".print(TAG)
                    if (json.isNullOrEmpty()) {
                        resultCall.invoke(null)
                        return
                    }
                    val responseData = Gson().fromJson(json, ResponseData::class.java)
                    val code = responseData.code
                    if (code == 0) {
                        lastTime = System.currentTimeMillis()
                        val data =
                            responseData.data.also { it?.lastTime = lastTime }
                        resultCall.invoke(data)
                    } else {
                        resultCall.invoke(null)
                    }
                }.onFailure {
                    "adList response data: ${it.message}".print("fetchAdConfigAsync")
                    resultCall.invoke(null)
                }
            }
        })
    }

    private fun isAdConfigExpired(): Boolean {
        return System.currentTimeMillis() - lastTime >= adExpiredTime * 1000
    }

}
