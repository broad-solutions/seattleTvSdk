package cn.coolplay.sdk.utils

import cn.coolplay.sdk.AdChannelType
import cn.coolplay.sdk.bean.Data
import cn.coolplay.sdk.bean.TokenData
import com.google.gson.Gson
import com.tencent.mmkv.MMKV

object Shares {
    private val mmkv: MMKV by lazy {
        MMKV.mmkvWithID("CoolPlay")
    }

    var authorInfo: TokenData? = null
        set(value) {
            if (value == null) {
                mmkv.remove("saveAuthorInfo")
            } else {
                mmkv.encode("saveAuthorInfo", Gson().toJson(value))
            }
            field = value
        }
        get() {
            val json = mmkv.decodeString("saveAuthorInfo")
            return if (json.isNullOrEmpty()) {
                null
            } else {
                Gson().fromJson(json, TokenData::class.java)
            }
        }

    var adConfigInfo: Data? = null
        set(value) {
            mmkv.encode("adConfigInfo", Gson().toJson(value))
            field = value
            "保存广告配置信息$value".print("Shares")
        }
        get() {
            val json = mmkv.decodeString("adConfigInfo")
            "获取广告配置信息$json".print("Shares")
            return if (json.isNullOrEmpty()) {
                null
            } else {
                Gson().fromJson(json, Data::class.java)
            }
        }

    fun saveAdChannel(channel: String, isInit: Boolean) {
        when (channel.lowercase()) {
            AdChannelType.WhaleTV.name.lowercase() -> {
                mmkv.encode(channel, isInit)
            }

            AdChannelType.AirMobi.name.lowercase() -> {
                mmkv.encode(channel, isInit)
            }
        }
    }

    fun getAdChannel(channel: String): Boolean {
        return mmkv.decodeBool(channel, true)
    }

}