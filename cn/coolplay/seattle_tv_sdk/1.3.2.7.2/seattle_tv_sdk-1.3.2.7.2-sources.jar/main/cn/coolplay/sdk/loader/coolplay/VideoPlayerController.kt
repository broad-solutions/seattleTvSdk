package cn.coolplay.sdk.loader.coolplay

import android.annotation.SuppressLint
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.ima.ImaAdsLoader
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.loader.AdRequestBuilder
import cn.coolplay.sdk.loader.CoolBaseControl
import cn.coolplay.sdk.loader.CoolPlayAdControl
import cn.coolplay.sdk.loader.CoolPlayAdListener
import cn.coolplay.sdk.player.ClPlayerView
import cn.coolplay.sdk.utils.print
import cn.coolplay.seattle_tv_sdk.databinding.ClLayoutPlayerBinding
import com.google.ads.interactivemedia.v3.api.AdEvent.AdEventType
import com.google.ads.interactivemedia.v3.api.player.AdMediaInfo
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer.VideoAdPlayerCallback
import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate
import com.google.gson.Gson

/**
 * 处理 IMA SDK 集成代码和事件的广告逻辑。
 */
@SuppressLint("UnsafeOptInUsageError")
class VideoPlayerController(
    adLoadController: CoolPlayAdControl,
    override var channel: String // 确保 channel 是通过构造函数初始化的
) : CoolBaseControl {
    private val imaRequestBuilder: AdRequestBuilder = adLoadController.adRequestBuilder
    private var imaAdsLoader: ImaAdsLoader? = null
    private val context get() = imaRequestBuilder.context
    private var exoPlayer: ExoPlayer? = null
    private var playerView: ClPlayerView? = null

    // 用于请求广告的 VAST 广告标签 URL。
    private var currentAdTagUrl: String? = null

    private val isOnlyContent: Boolean
        get() =
            currentAdTagUrl.isNullOrEmpty() || imaRequestBuilder.onlyContent

    @UnstableApi
    private fun getMediaSourceFactory() =
        DefaultMediaSourceFactory(
            DefaultDataSource.Factory(
                context
            )
        )

    private var adEventListener: CoolPlayAdListener = imaRequestBuilder.adsLoadListener.also {
        it.channel = channel
        "设置AdEventListener $channel valueChannel:${it.channel}".print(TAG)
    }


    fun setCurrentAdTagUrl(adTagUrl: String?) {
        currentAdTagUrl = adTagUrl
    }


    override fun loadAd() {
        "loadAd channel $channel isVMap${imaRequestBuilder.isVMap} 开始播放广告".print(TAG) // 确保 channel 在这里有值
        imaRequestBuilder.onAdsLoading(channel)
        val defaultMediaSourceFactory = getMediaSourceFactory()

        playerView = adEventListener.attachPlayer(context)
            ?: ClLayoutPlayerBinding.inflate(LayoutInflater.from(context)).root

        playerView?.apply {
            "player ready".print(TAG)
            val layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            if (!imaRequestBuilder.isVMap) {
                useController = false
            }
            imaRequestBuilder.adContainer.also {
                // 禁止穿透
                it.isClickable = true
                // 如果是TV 设置交代呢
                if (CoolPlaySdk.isTVUiMode) {
                    it.isFocusable = true
                    it.isFocusableInTouchMode = true
                    it.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
                }
                it.addView(this, layoutParams)
            }
            imaAdsLoader =
                ImaAdsLoader.Builder(context)
                    .setDebugModeEnabled(CoolPlaySdk.isDebug).setAdEventListener { adEvent ->
                        adEventListener.onAdEvent(adEvent)
                        when (adEvent.type) {
                            AdEventType.CONTENT_PAUSE_REQUESTED -> {
                                // 内容暂停 恢复广告
                                upDateVolume(true)
                            }

                            AdEventType.CONTENT_RESUME_REQUESTED -> {
                                // 广告暂停,恢复内容
                                upDateVolume(false)
                            }

                            else -> {}
                        }
                    }.setAdErrorListener { error ->
                        "onAdError ${error.error}".print(TAG)
                        // 当加载或播放广告时引发的错误事件。
                        val msg = error.error.toString()
                        val map = hashMapOf("msg" to msg, "vast" to (currentAdTagUrl ?: ""))
                        adEventListener.onAdError(Gson().toJson(map))

                    }.setVideoAdPlayerCallback(object : VideoAdPlayerCallback {
                        override fun onAdProgress(p0: AdMediaInfo, p1: VideoProgressUpdate) {}

                        override fun onBuffering(p0: AdMediaInfo) {}

                        override fun onContentComplete() {
                            "onContentComplete".print(TAG)
                        }

                        override fun onEnded(p0: AdMediaInfo) {
                            "onEnded".print(TAG)
                        }

                        override fun onError(p0: AdMediaInfo) {
                            "onError ${p0.url}".print(TAG)
                        }

                        override fun onLoaded(p0: AdMediaInfo) {
                            "onLoaded ${p0.url}".print(TAG)
                        }

                        override fun onPause(p0: AdMediaInfo) {
                            "onPause ${p0.url}".print(TAG)
                        }

                        override fun onPlay(p0: AdMediaInfo) {
                            "onPlay ${p0.url}".print(TAG)
                            adEventListener.onCompleteAd(p0.url)
                        }

                        override fun onResume(p0: AdMediaInfo) {
                            "onResume ${p0.url}".print(TAG)
                        }

                        override fun onVolumeChanged(p0: AdMediaInfo, p1: Int) {}
                    }).apply {
                        val adPreloadTimeoutMs = imaRequestBuilder.adPreloadTimeoutMs
                        if (adPreloadTimeoutMs > 0) {
                            setAdPreloadTimeoutMs(adPreloadTimeoutMs)
                        }
                        setFocusSkipButtonWhenAvailable(imaRequestBuilder.enableFocusSkipButton)
                        if (imaRequestBuilder.mLoadVideoTimeout > 0) {
                            setMediaLoadTimeoutMs(imaRequestBuilder.mLoadVideoTimeout)
                        }
                        val mVastLoadTimeoutMs = imaRequestBuilder.requestAdTimeOut.toInt()
                        if (mVastLoadTimeoutMs > 0) {
                            setVastLoadTimeoutMs(mVastLoadTimeoutMs)
                        }
                        val mBitrate = imaRequestBuilder.bitrate
                        if (mBitrate > 0) {
                            setMaxMediaBitrate(mBitrate)
                        }
                        imaRequestBuilder.mimeTypes?.also {
                            if (it.isNotEmpty()) {
                                setAdMediaMimeTypes(it)
                            }
                        }
                    }
                    .build()

            // 创建并设置媒体源工厂
            defaultMediaSourceFactory.setLocalAdInsertionComponents(
                { imaAdsLoader }, this
            )
            exoPlayer =
                ExoPlayer.Builder(context).setMediaSourceFactory(defaultMediaSourceFactory)
                    .setRenderersFactory(DefaultRenderersFactory(context).also {
                        it.setEnableDecoderFallback(true) // 启用解码器回退机制
                            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON) // 启用扩展解码
                    })
                    .setDeviceVolumeControlEnabled(true)
                    .build()
            exoPlayer?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    "onIsPlayingChanged $isPlaying".print(TAG)
                    val isPlayingAd = isPlayingAd()
                    if (!isPlayingAd) {
                        if (isPlaying) {
                            adEventListener.onResume()
                        } else {
                            adEventListener.onPause()
                        }
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    super.onPlayerError(error)
                    "onPlayerError $error".print(TAG)
                    adEventListener.onAdError(error.message ?: "onPlayerError")
                    adEventListener.onError()
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    super.onPlaybackStateChanged(playbackState)
                    "onPlaybackStateChanged $playbackState--isPlayingAd:${isPlayingAd()}".print(
                        TAG
                    )
                    when (playbackState) {
                        Player.STATE_READY -> {
                            val isPlayingAd = isPlayingAd()
                            // 内容暂停 恢复广告
                            upDateVolume(isPlayingAd)
                            // 播放开始
                            if (isPlayingAd) {
                                adEventListener.onPlayAd()
                            } else {
                                adEventListener.onPlay()
                            }
                        }

                        Player.STATE_ENDED -> {
                            val isPlayingAd = isPlayingAd()
                            // 播放开始
                            if (!isPlayingAd) {
                                adEventListener.onComplete()
                            }
                        }

                        else -> {}
                    }
                }
            })
            imaAdsLoader?.setPlayer(exoPlayer)
            player = exoPlayer
            updateControlComponent()
            startAd()
        } ?: run {
            "playerView is null".print(TAG)
        }
    }

    /**
     * //静音 0、全部  1、广告静音 2 全部开启声音
     */
    private fun upDateVolume(playingAd: Boolean) {
        when (val videoMuted = imaRequestBuilder.mVideoMute) {
            0, 2 -> {
                setMuted(videoMuted == 0)
            }

            1 -> {
                if (playingAd) {
                    setMuted(true)
                } else {
                    setMuted(false)
                }
            }
        }

    }

    private fun isPlayingAd(): Boolean {
        val player = playerView?.player
        return player != null && player.isCommandAvailable(Player.COMMAND_GET_CURRENT_MEDIA_ITEM)
                && player.isPlayingAd
                && player.playWhenReady
    }

    private fun setMuted(muted: Boolean) {
        "setMuted $muted".print(TAG)
        exoPlayer?.apply {
            if (availableCommands.contains(Player.COMMAND_SET_VOLUME)) {
                exoPlayer?.volume = if (muted) 0f else 1f
            }
        }
    }

    private fun startAd() {
        val mediaItem = MediaItem.Builder().setUri(imaRequestBuilder.contentVideoUrl).apply {
            //只播放视频
            if (!isOnlyContent) {
                setAdsConfiguration(
                    MediaItem.AdsConfiguration.Builder(Uri.parse(currentAdTagUrl)).build()
                )
            }
        }.build()
        exoPlayer?.setMediaItem(mediaItem)
        exoPlayer?.prepare()
        exoPlayer?.playWhenReady = true
    }


    /**
     * 保存视频的位置，无论是内容还是广告。可以在应用暂停时调用，例如。
     */
    override fun pause() {
        exoPlayer?.pause()
    }

    /**
     * 恢复之前保存的视频进度位置。可以在应用恢复时调用。
     */
    override fun resume() {
        exoPlayer?.play()
    }

    /** 销毁播放器。  */
    override fun release() {
        try {
            "release $channel".print(TAG)
            playerView?.post {
                imaAdsLoader?.release()
                imaAdsLoader = null
                exoPlayer?.release()
                exoPlayer = null
            }
            imaRequestBuilder.adContainer.removeView(playerView)
            //上报广告事件
            adEventListener.uploadEvent()
            Runtime.getRuntime().gc()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    companion object {
        private const val TAG = "VideoPlayerController"
    }
}
