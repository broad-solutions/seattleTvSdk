package cn.coolplay.sdk.loader.banner

import android.view.ViewGroup
import cn.coolplay.sdk.AdImaType
import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.loader.AdRequestBuilder
import cn.coolplay.sdk.loader.CoolPlayAdListener

@Keep
class BannerRequest(
    adContainer: ViewGroup,
    override var mVideoMute: Int = 0,//静音
    override var onlyContent: Boolean = false,
    override var isVMap: Boolean = false,
    override var adsLoadListener: CoolPlayAdListener// 单个渠道失败回调用
) : AdRequestBuilder(
    adContainer,
    AdImaType.BANNER,
    adsLoadListener = adsLoadListener,
)