package cn.coolplay.sdk.report

import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.annotation.KeepName
import cn.coolplay.sdk.bean.ResponseData
import cn.coolplay.sdk.http.Http.okHttpClient
import cn.coolplay.sdk.utils.Shares.authorInfo
import cn.coolplay.sdk.utils.print
import com.google.gson.Gson
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException

@KeepName
object UploadEvent {
    private const val baseUrl = "https://eventapi.ci-ads.com"

    const val TAG = "UploadEvent"

    fun postData(data: Any, eventName: String, eventType: String): Map<String, Any> {
        val events = listOf(
            mapOf(
                "data" to data,
                "ext" to "",
                "name" to eventName,
                "type" to eventType
            )
        )

        return mapOf(
            "events" to events,
            "packageName" to CoolPlaySdk.packageName
        )
    }


    fun uploadData(params: Map<String, Any>) {
        "上传事件是${params}".print("uploadData")
        post(
            "/v1/event/upload",
            params,
            object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    // 处理请求失败的情况
                    "请求失败：${e.message}".print("uploadData")
                }

                override fun onResponse(call: Call, response: Response) {
                    // 处理请求成功的情况 对返回的数据进行处理
                    try {
                        val responseBody = response.body?.string()
                        val result = Gson().fromJson(responseBody, ResponseData::class.java)
                        if (result.code == 0) {
                            "=================upload 数据回传成功=================================".print(
                                TAG
                            )
                        } else {
                            "=================================数据回传失败${result.msg}==========================".print(
                                TAG
                            )
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }
            })
    }

    // GET请求
    fun get(url: String, params: Map<String, Any>, callback: Callback) {
        val requestUrl = params.map { (key, value) ->
            "$key=$value"
        }.joinToString("&")
        val request = Request.Builder()
            .apply {
                url(baseUrl.plus(url).plus("?").plus(requestUrl))
                header("Authorization", "Bearer ${authorInfo?.access_token}")
            }
            .build()
        okHttpClient.newCall(request).enqueue(callback)
    }

    // POST请求
    fun post(url: String, params: Map<String, Any>, callback: Callback) {
        val jsonObject = JSONObject(params)
        val jsonBody = jsonObject.toString()
        val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
        val body = jsonBody.toRequestBody(mediaType)
        "提交的数据是--->$jsonObject".print("post")
        val request = Request.Builder().apply {
            url(baseUrl + url)
            header("Authorization", "Bearer ${authorInfo?.access_token}")
            post(body)
        }.build()

        okHttpClient.newCall(request).enqueue(callback)
    }
}

