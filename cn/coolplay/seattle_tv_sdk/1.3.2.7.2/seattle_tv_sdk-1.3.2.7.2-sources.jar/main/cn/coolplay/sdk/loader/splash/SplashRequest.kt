package cn.coolplay.sdk.loader.splash

import android.view.ViewGroup
import cn.coolplay.sdk.AdImaType
import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.loader.AdRequestBuilder
import cn.coolplay.sdk.loader.CoolPlayAdListener

@Keep
class SplashRequest(
    adContainer: ViewGroup,
    override var mVideoMute: Int = 0,//静音
    override var onlyContent: Boolean = false,
    override var isVMap: Boolean = false,
    override var adsLoadListener: CoolPlayAdListener// 所以事件回调
) : AdRequestBuilder(
    adContainer,
    AdImaType.SPLASH,
    adsLoadListener = adsLoadListener,
) {
    var useActivity: Boolean = true
}