package cn.coolplay.sdk.loader.section

import cn.coolplay.sdk.loader.CoolPlayAdControl

class SectionController(
    adRequestBuilder: SectionRequest,
    channel: String,
    unitViewId: String?
) : CoolPlayAdControl(adRequestBuilder, channel, unitViewId)
