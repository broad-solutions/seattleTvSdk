package cn.coolplay.sdk.task

import cn.coolplay.sdk.RealAdCoolPlay
import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.bean.TokenData
import cn.coolplay.sdk.http.Http.okHttpClient
import cn.coolplay.sdk.utils.Shares.authorInfo
import cn.coolplay.sdk.utils.print
import com.google.gson.Gson
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class SyncTokenTask(private val adCoolPlay: RealAdCoolPlay) : ITask<String?>() {
    private val oauthUrl by lazy {
        val param = mapOf<String, Any>(
            "client_id" to adCoolPlay.clientId,
            "client_secret" to adCoolPlay.clientSecret,
            "grant_type" to adCoolPlay.grantType,
        ).map { (key, value) ->
            "$key=$value"
        }.joinToString("&")
        "https://oauthapi.ci-ads.com/oauth/token?".plus(param)
    }


    private var lastTime = 0L
    private var token: String? = null
    private var tokenExpiredTime = 0
    private val mutex = Mutex()

    init {
        authorInfo?.also {
            lastTime = it.lastTime
            token = it.access_token
            tokenExpiredTime = it.expires_in
        }

    }


    override suspend fun execute(): String? {
        return mutex.withLock {
            if (authorInfo == null || token == null || isTokenExpired()) {
                token = refreshTokenAsync()
            }
            "token $token".print(TAG)
            token
        }
    }

    @Keep
    private fun setToken(res: String) {
        val accessTokenResponse = Gson().fromJson(res, TokenData::class.java)
        tokenExpiredTime = accessTokenResponse.expires_in
        token = accessTokenResponse.access_token
        lastTime = System.currentTimeMillis()
        accessTokenResponse.lastTime = lastTime
        authorInfo = accessTokenResponse
    }


    private suspend fun refreshTokenAsync(): String? {
        return suspendCoroutine { continuation ->
            if (adCoolPlay.clientId.isEmpty() || adCoolPlay.clientSecret.isEmpty()) {
                continuation.resume(null)
            } else {
                fetchToken {
                    "refreshTokenAsync $it".print(TAG)
                    if (it.isNullOrEmpty()) {
                        continuation.resume(null)
                    } else {
                        setToken(it)
                        continuation.resume(token)
                    }
                }
            }
        }
    }

    private fun fetchToken(resultCall: (String?) -> Unit) {
        val request = Request.Builder().url(oauthUrl).build()
        okHttpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                "fetchToken  onFailure data: ${e.message}".print(TAG)
                resultCall.invoke(null)

            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    "fetchToken response ${response.body?.string()}: ${response.message}".print(TAG)
                    resultCall.invoke(null)
                    return
                }
                val result = response.body?.string()
                "fetchToken result:$result".print(TAG)
                resultCall.invoke(result)
            }
        })
    }

    private fun isTokenExpired(): Boolean {
        return System.currentTimeMillis() - lastTime >= tokenExpiredTime * 1000
    }

    companion object {
        var TAG: String = "SyncTokenTask"
    }
}
