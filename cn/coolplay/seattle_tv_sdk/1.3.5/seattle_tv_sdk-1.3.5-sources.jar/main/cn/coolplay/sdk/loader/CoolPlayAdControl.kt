package cn.coolplay.sdk.loader

import cn.coolplay.sdk.AdChannelType
import cn.coolplay.sdk.CoolPlaySdk
import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.loader.coolplay.VideoPlayerController

@Keep
abstract class CoolPlayAdControl(
    var adRequestBuilder: AdRequestBuilder,
    final override var channel: String,
    private var unitViewId: String? = null
) : CoolBaseControl {

    private val baseControl: CoolBaseControl by lazy {
        when (channel.lowercase()) {
            AdChannelType.WhaleTV.name.lowercase(), AdChannelType.AirMobi.name.lowercase() -> {
                CoolPlaySdk.initController(
                    this,
                    channel,
                    unitViewId!!
                )
            }

            else -> {
                //Vast link
                VideoPlayerController(
                    this,
                    channel,
                ).apply { setCurrentAdTagUrl(unitViewId) }

            }
        }
    }

    override fun loadAd() {
        baseControl.loadAd()
    }

    override fun pause() {
        baseControl.pause()
    }

    override fun release() {
        baseControl.release()
    }

    override fun resume() {
        baseControl.resume()
    }

    override fun isPlaying(): Boolean {
        return baseControl.isPlaying()
    }
}