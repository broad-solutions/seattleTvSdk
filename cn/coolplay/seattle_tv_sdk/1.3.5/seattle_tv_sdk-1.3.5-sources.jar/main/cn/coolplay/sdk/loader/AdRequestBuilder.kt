package cn.coolplay.sdk.loader

import android.annotation.SuppressLint
import android.content.Context
import android.view.ViewGroup
import androidx.media3.exoplayer.DefaultRenderersFactory
import cn.coolplay.sdk.AdImaType
import cn.coolplay.sdk.annotation.Keep

@SuppressLint("UnsafeOptInUsageError")
@Keep
abstract class AdRequestBuilder(
    open val adContainer: ViewGroup, var adImaType: AdImaType,//广告类型
    open var adsLoadListener: CoolPlayAdListener// 单个渠道失败回调用
) {
    open var coolPlayAdControl: CoolPlayAdControl? = null
    val context: Context get() = adContainer.context
    open var mVideoMute: Int = 0 //静音 0、全部  1、广告静音 2 全部开启声音
    open var isVMap: Boolean = false
    open var onlyContent: Boolean = false //倒计时
    open var requestAdTimeOut: Long = 8000L //请求广告超时时间 防止google 异常
    open var mLoadVideoTimeout: Int = -1//加载超时时间
    open var bitrate: Int = -1 //码率
    open var mimeTypes: List<String>? = null //mimeTypes
    open var enableFocusSkipButton: Boolean = true//是否显示跳过按钮
    open var adPreloadTimeoutMs: Long = -1L //预加载时间,
    open var channel: String? = null//广告渠道 用于测试制定的渠道
    open var cache: Boolean = false
    open var renderersFactory: DefaultRenderersFactory? = null

    // 内容视频的 URL。
    open var contentVideoUrl: String? = null

    open var contentVideoList = arrayListOf<String>()

    fun resume() = coolPlayAdControl?.resume()
    fun pause() = coolPlayAdControl?.pause()
    fun release() {
        contentVideoList.clear()
        coolPlayAdControl?.release()
        coolPlayAdControl = null
    }


    val controller get() = coolPlayAdControl

    fun onAdsLoading(channel: String) {
        adsLoadListener.onLoading(channel)
    }

}