package cn.coolplay.sdk.player

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.media3.common.C
import androidx.media3.ui.TimeBar
import cn.coolplay.sdk.annotation.Keep
import cn.coolplay.sdk.annotation.KeepMember
import cn.coolplay.seattle_tv_sdk.R
import java.util.concurrent.CopyOnWriteArraySet

@SuppressLint("UnsafeOptInUsageError")
open class ProgressTimeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : ConstraintLayout(context, attrs, defStyleAttr), TimeBar {
    private var duration: Long = 0
    private var position: Long = 0
    private var bufferedPosition: Long = 0
    private var maxDuration: Int = 0
    private var keyCountIncrement = 0
    private var keyTimeIncrement: Long = 0
    private var adGroupCount = 0
    private var adGroupTimesMs: LongArray? = null
    private var playedAdGroups: BooleanArray? = null

    private var listeners: CopyOnWriteArraySet<TimeBar.OnScrubListener?>? = null
    private var progressListeners: CopyOnWriteArraySet<ProgressUpdateListener>? = null

    @Keep
    interface ProgressUpdateListener {
        fun onProgressUpdate(duration: Long, position: Long, bufferedPosition: Long)
    }

    @Keep
    fun addProgressListener(listener: ProgressUpdateListener) {
        progressListeners?.add(listener)
    }

    @Keep
    fun removeProgressListener(listener: ProgressUpdateListener) {
        progressListeners?.remove(listener)
    }

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.ProgressTimeView)
        maxDuration = a.getInt(R.styleable.ProgressTimeView_max_duration, 0)
        a.recycle()
        listeners = CopyOnWriteArraySet<TimeBar.OnScrubListener?>()
        progressListeners = CopyOnWriteArraySet<ProgressUpdateListener>()
    }

    override fun addListener(listener: TimeBar.OnScrubListener) {
        listeners!!.add(listener)
    }

    override fun removeListener(listener: TimeBar.OnScrubListener) {
        listeners!!.remove(listener)
    }

    override fun setKeyTimeIncrement(time: Long) {
        keyCountIncrement = C.INDEX_UNSET
        keyTimeIncrement = time
    }

    override fun setKeyCountIncrement(count: Int) {
        keyCountIncrement = count
        keyTimeIncrement = C.TIME_UNSET

    }

    override fun setPosition(position: Long) {
        if (this.position == position) {
            return
        }
        this.position = position
        update()

    }

    override fun setBufferedPosition(bufferedPosition: Long) {
        if (this.bufferedPosition == bufferedPosition) {
            return
        }
        this.bufferedPosition = bufferedPosition
        update()
    }

    override fun setDuration(duration: Long) {
        if (this.duration == duration) {
            return
        }
        this.duration = duration
        update()

    }

    override fun getPreferredUpdateDelay(): Long {
        return if (maxDuration == 0 || duration == 0L || duration == C.TIME_UNSET) Long.MAX_VALUE else duration / maxDuration
    }

    override fun setAdGroupTimesMs(
        adGroupTimesMs: LongArray?, playedAdGroups: BooleanArray?, adGroupCount: Int
    ) {
        this.adGroupCount = adGroupCount
        this.adGroupTimesMs = adGroupTimesMs
        this.playedAdGroups = playedAdGroups
        update()
    }

    private fun update() {
        progressListeners?.forEach {
            it.onProgressUpdate(duration, position, bufferedPosition)
        }
    }

}